Для запуска проекта необходимо установить Node.JS https://nodejs.org/en/ ,
затем выполнить следующую последовательность команд: npm install ->
npm run start -> открыть в браузере страницу по адресу http://localhost:8888/index.html

Либо разорхивировать архив all_include_archive в отдельную папку
и  выполнить последовательность команд: npm run start -> открыть в браузере страницу по адресу http://localhost:8888/index.html